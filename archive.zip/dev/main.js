// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [function (require, module) {
      module.exports = exports;
    }, {}];
  };

  var error;
  for (var i = 0; i < entry.length; i++) {
    try {
      newRequire(entry[i]);
    } catch (e) {
      // Save first error but execute all entries
      if (!error) {
        error = e;
      }
    }
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  parcelRequire = newRequire;

  if (error) {
    // throw error from earlier, _after updating parcelRequire_
    throw error;
  }

  return newRequire;
})({"../../node_modules/lodash.debounce/index.js":[function(require,module,exports) {
var global = arguments[3];
/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the `TypeError` message for "Functions" methods. */
var FUNC_ERROR_TEXT = 'Expected a function';

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** `Object#toString` result references. */
var symbolTag = '[object Symbol]';

/** Used to match leading and trailing whitespace. */
var reTrim = /^\s+|\s+$/g;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        result = wait - timeSinceLastCall;

    return maxing ? nativeMin(result, maxWait - timeSinceLastInvoke) : result;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return !!value && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && objectToString.call(value) == symbolTag);
}

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = value.replace(reTrim, '');
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = debounce;

},{}],"utils/is-mobile.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
// device sniffing for mobile
var isMobile = {
  android: function android() {
    return navigator.userAgent.match(/Android/i);
  },
  blackberry: function blackberry() {
    return navigator.userAgent.match(/BlackBerry/i);
  },
  ios: function ios() {
    return navigator.userAgent.match(/iPhone|iPad|iPod/i);
  },
  opera: function opera() {
    return navigator.userAgent.match(/Opera Mini/i);
  },
  windows: function windows() {
    return navigator.userAgent.match(/IEMobile/i);
  },
  any: function any() {
    return isMobile.android() || isMobile.blackberry() || isMobile.ios() || isMobile.opera() || isMobile.windows();
  }
};
var _default = isMobile;
exports.default = _default;
},{}],"sorting.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function sortDates(a, b) {
  return a.date - b.date;
}

function sortNumberStories(a, b) {
  a = a.values.length;
  b = b.values.length;
  return b - a;
}

function sortDatesKey(a, b) {
  a = a.key.split('-');
  b = b.key.split('-');
  return new Date(a[0], a[1], 1) - new Date(b[0], b[1], 1);
}

function sortDatesYearMonth(a, b) {
  a = a.yearMonth.split('-');
  b = b.yearMonth.split('-');
  return new Date(a[0], a[1], 1) - new Date(b[0], b[1], 1);
}

var _default = {
  sortNumberStories: sortNumberStories,
  sortDatesKey: sortDatesKey,
  sortDatesYearMonth: sortDatesYearMonth,
  sortDates: sortDates
};
exports.default = _default;
},{}],"graphic.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _sorting = _interopRequireDefault(require("./sorting"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

// Data
var data;
var articleData;
var cleanedArticleData;
var timelineAnnotationList;
var paperData;
var cleanedPaperData;
var mergedData;
var annotations;
var parseDatePaper = d3.timeParse("%Y_%m_%d");
var parseDateArticle = d3.timeParse("%Y/%m/%d"); // Dimensions
// let margin = {'left':100, 'right':200, 'top':120, 'bottom':100};

var margin = {
  'left': 10,
  'right': 10,
  'top': 10,
  'bottom': 10
};
var width;
var height;
var yScale;
var rScale; // DOM + joins

var $footer;
var $conclusion;
var $coverRight;
var $coverLeft;
var $buttonArrowCover;
var $buttonArrowForward;
var $buttonArrowBack;
var simulation;
var $tooltip;
var $tooltipTitle;
var $tooltipAuthor;
var $tooltipBody;
var $tooltipLink;
var $body;
var $svgBox;
var $svg;
var $timeline;
var $timelineAxis;
var $axisLine;
var $timelineCirclesG;
var $timelineAxisForeground;
var $timelineAxisBackground;
var articlesJoin;
var $articleCells;
var $articleCircles; // CONSTANTS

var RAD_PAPER = 20;
var RAD_ARTICLE = 5;
var COL_PAPER = '#559DB9';
var COL_ARTICLE = '#E17D7F';
var $scrollhint = d3.select('.scroll-hint'); // Tracking

var slideCount = 0; // Notes to self
// - left margin set to 2x that of right margin atm

function setNavigationFunctionality() {
  $buttonArrowCover.on('click', handleForwardClick);
  $buttonArrowForward.on('click', handleForwardClick);
  $buttonArrowBack.on('click', handleBackClick);
}

function handleMouseEnter(d, i, n) {
  d3.event.stopPropagation();

  if (width > 600) {
    var _d3$mouse = d3.mouse(this),
        _d3$mouse2 = _slicedToArray(_d3$mouse, 2),
        xCoord = _d3$mouse2[0],
        yCoord = _d3$mouse2[1];

    var htmlContents = d.data.type === 'article' ? "<p class='sci-title'>".concat(d.data.hed_main, "</p><p class='sci-body'>").concat(d.data.abstract.slice(0, 200), "...</p>") : "<p class='sci-title'>".concat(d.data.hed_main, "</p><p class='sci-author'>").concat(d.data.author, "</p><p class='sci-body'>").concat(d.data.abstract.slice(0, 200), "...</p>");
    d3.selectAll('.paper').classed('faded', true);
    d3.selectAll('.article').classed('faded', true);
    d3.select(this).classed('highlight', true);
    d3.select(this).on('click', function (d) {
      d.data.type === 'article' ? window.open(d.data.web_url) : window.open(d.data.link);
    });
    $axisLine.st('opacity', 0);
    $tooltip.classed('hidden', false).st('left', xCoord + 20).st('top', yCoord).st('max-width', function () {
      return width > 600 ? width / 4 : width / 3;
    }).html(htmlContents);
  } else {
    if (d.data.type === 'article') {
      $tooltipTitle.text(d.data.hed_main);
      $tooltipAuthor.classed('hidden', true);
      $tooltipBody.text("".concat(d.data.abstract.slice(0, 200), "..."));
      $tooltipLink.on('click', function () {
        d3.event.stopPropagation();
        window.open(d.data.web_url);
      });
    } else {
      $tooltipTitle.text(d.data.hed_main);
      $tooltipAuthor.text(d.data.author);
      $tooltipBody.text("".concat(d.data.abstract.slice(0, 200), "..."));
      $tooltipLink.on('click', function () {
        d3.event.stopPropagation();
        window.open(d.data.link);
      });
    }

    var _d3$mouse3 = d3.mouse(this),
        _d3$mouse4 = _slicedToArray(_d3$mouse3, 2),
        _xCoord = _d3$mouse4[0],
        _yCoord = _d3$mouse4[1];

    d3.selectAll('.paper').classed('faded', true);
    d3.selectAll('.article').classed('faded', true);
    d3.select(this).classed('highlight', true);
    $tooltip.classed('hidden', false).st('left', width * 0.1).st('top', _yCoord).st('max-width', function () {
      return 0.8 * width;
    }) // .on('click', handleMouseLeave)   
    .on('click', function () {
      window.alert('clicked');
    }).on('mouseenter', function () {
      window.alert('clicked');
    }); // $tooltipLink.classed('hidden',false)
    // $tooltipLink.on('click',()=>{
    // })
  }
}

function handleMouseLeave(d) {
  $tooltip.classed('hidden', true);
  d3.selectAll('.paper').classed('faded', false);
  d3.selectAll('.article').classed('faded', false);
  d3.selectAll('.paper').classed('highlight', false);
  d3.selectAll('.article').classed('highlight', false);
  $axisLine.st('opacity', 1);
}

function scrollTo(element) {
  window.scroll({
    behavior: 'smooth',
    left: 0,
    top: element.offsetTop
  });
}

function handleBackClick() {
  if (slideCount === 1) {
    $coverRight.classed('hidden', false);
    $coverLeft.classed('hidden', false);
    $coverRight.classed('slide', false);
    $coverLeft.classed('slide', false);
    d3.select('.arrow-cover').classed('hidden', false);
    d3.select('.arrow-back-to-intro').classed('hidden', true);
    d3.selectAll('.timeline-intro').classed('hidden', true);
    d3.select('.intro').classed('hidden', false);
    d3.select('.cover-container').classed('hidden', false);
    slideCount -= 1;
    $buttonArrowForward.classed('hidden', true);
    $buttonArrowBack.classed('hidden', true);
  }

  if (slideCount === 2) {
    d3.select(".timeline-svg").classed('hidden', true);
    d3.selectAll('.timeline-intro').classed('hidden', true);
    d3.selectAll('.slide-1').classed('hidden', false);
    slideCount -= 1;
    $buttonArrowForward.classed('hidden', false);
    $buttonArrowBack.classed('hidden', false);
  }

  if (slideCount === 3) {
    d3.select(".timeline-svg").classed('hidden', true);
    d3.selectAll('.timeline-intro').classed('hidden', true);
    d3.selectAll('.slide-2').classed('hidden', false);
    slideCount -= 1;
    $buttonArrowForward.classed('hidden', false);
    $buttonArrowBack.classed('hidden', false);
  }

  if (slideCount === 4) {
    $footer.classed('hidden', true);
    $conclusion.classed('hidden', true);
    $svgBox.classed('hidden', true);
    d3.select(".timeline-svg").classed('hidden', true);
    d3.selectAll('.timeline-intro').classed('hidden', true);
    d3.selectAll('.slide-3').classed('hidden', false);
    d3.select('div.intro').classed('hidden', false);
    slideCount -= 1;
    $buttonArrowForward.classed('hidden', false);
    $buttonArrowBack.classed('hidden', false);
    $scrollhint.classed('is-visible', false);
  } else {} //   const el = d3.select('#content').node();
  //   scrollTo(el)
  //   setTimeout(function() {
  //     d3.select(`.timeline-intro`).classed('slide', false)
  //   }, 300)
  //   setTimeout(function() {
  //     $coverRight.classed('slide', false)
  //     $coverLeft.classed('slide', false)
  //     $scrollhint.classed('is-visible', true)
  //   }, 800)
  //   $buttonArrowCover.st('display','flex')
  //   d3.select(`.intro`).st('display','block')
  //   d3.select(`.timeline-intro`).st('display','block')
  //   d3.select('body').st('overflow', 'hidden')
  //   slideCount-=2
  // Start of my commented code
  //     if (slideCount === 1){
  //         d3.select('.timeline-svg')
  //         .st('display','none')
  //         $coverRight.classed('slide', false)
  //         $coverLeft.classed('slide', false)
  //         d3.select(`.cover-container`).st('display','flex')   
  //         d3.select(`.intro`).st('display','block')  
  //         $footer.classed('hidden',true)
  //         slideCount-=1        
  //         // d3.select(`.slide-${slideCount}`).st('display','block')   
  //         // d3.select(`.slide-${slideCount}`).classed('hidden',false)    
  //     }
  //     else if (slideCount === 2){
  //         d3.select(`.timeline-svg`).st('display','none')
  //         d3.select(`.timeline-intro`).st('display','block')
  //         $footer.classed('hidden',true)
  //         slideCount-=1 
  //     }
  //   END of my commented code

}

function handleForwardClick() {
  if (slideCount === 0) {
    $coverRight.classed('slide', true);
    $coverLeft.classed('slide', true);
    d3.select('.arrow-cover').classed('hidden', true);
    d3.selectAll('end').classed('hidden', true); // d3.select('.intro')
    // .classed('hidden', true)
    // d3.select('.cover-container')
    // .classed('hidden',true)

    d3.select('.slide-1').classed('hidden', false);
    slideCount += 1;
    $svgBox.classed('hidden', true);
    $footer.classed('hidden', true);
    $buttonArrowForward.classed('hidden', false);
    $buttonArrowBack.classed('hidden', false);
    setTimeout(function () {
      $coverRight.classed('hidden', true);
      $coverLeft.classed('hidden', true);
    }, 500);
  } else if (slideCount === 1) {
    d3.select('.cover-container').classed('hidden', true);
    d3.selectAll('end').classed('hidden', true);
    d3.selectAll('.timeline-intro').classed('hidden', true);
    d3.select('.slide-2').classed('hidden', false);
    slideCount += 1;
    $svgBox.classed('hidden', true);
    $footer.classed('hidden', true);
    $buttonArrowForward.classed('hidden', false);
    $buttonArrowBack.classed('hidden', false);
  } else if (slideCount === 2) {
    d3.select('.cover-container').classed('hidden', true);
    d3.selectAll('end').classed('hidden', true);
    d3.selectAll('.timeline-intro').classed('hidden', true);
    d3.select('.slide-3').classed('hidden', false);
    slideCount += 1;
    $svgBox.classed('hidden', true);
    $footer.classed('hidden', true);
    $buttonArrowForward.classed('hidden', false);
    $buttonArrowBack.classed('hidden', false);
  } else {
    $conclusion.classed('hidden', false);
    d3.select('.cover-container').classed('hidden', true);
    d3.selectAll('end').classed('hidden', false);
    $svgBox.classed('hidden', false);
    $footer.classed('hidden', false); // $buttonArrowCover.st('display','none')

    d3.select(".timeline-svg").st('display', 'block'); // d3.select(`.timeline-intro`).classed('slide', 'true')
    // d3.select(`.intro`).st('display','none')

    d3.selectAll('.timeline-intro').classed('hidden', true);
    $buttonArrowForward.classed('hidden', true);
    $buttonArrowBack.classed('hidden', false);
    d3.select('div.intro').classed('hidden', true);
    $scrollhint.classed('is-visible', true);
    slideCount += 1; // //         START of my edited code
    //         d3.select(`.timeline-intro`).st('display','none')
    //         $footer.classed('hidden',false)
    //         slideCount+=1 
    //     }
    //           END of my edited code

    d3.select('body').st('overflow', 'auto');
  }
}

function createSimulation() {
  function setForceX(type) {
    // if (type==='article') return width/1.98
    // return width/2.02
    return width / 2;
  }

  simulation = d3.forceSimulation(mergedData).force('x', d3.forceX(function (d) {
    return setForceX(d.type);
  })).force('y', d3.forceY(function (d) {
    return yScale(d.date);
  }).strength(1)).force('collide', d3.forceCollide(function (d) {
    return d.type === 'article' ? 5 : 20;
  })).stop();

  for (var i = 0; i < 220; ++i) {
    simulation.tick();
  }
}

function createTimelineAnnotations(mergedData) {
  var widthWrap = d3.select('body').node().offsetWidth;
  var maxX = widthWrap / 2;

  function removeOverlap(title) {
    if (title === 'The end: no autism/vaccine link') return 0;
    if (title === 'In America...') return 200;
    if (title === 'Study retracted') return 100;
    if (title === 'Measles in US') return -100;
    if (title === 'Presidential debates') return 200;
    if (title === 'Political manipulation') return 100;
    return 0;
  }

  function setXOffset(i, itemX) {
    if (widthWrap > 600) {
      return i % 2 ? -200 : 100;
    } else {
      if (i % 2) {
        var xMove = 0;
        var setLocation = 0.4 * widthWrap;
        xMove = -(itemX - setLocation);
        return xMove;
      } // eslint-disable-next-line no-else-return
      else {
          var _xMove = 0;

          var _setLocation = 0.61 * widthWrap;

          _xMove = _setLocation - itemX;
          return _xMove;
        }
    }
  }

  var annotationItemsOnly = mergedData.filter(function (item) {
    return item.annotation;
  });
  var annotationsFormatted = annotationItemsOnly.map(function (item, index) {
    var annotationObject = {};
    annotationObject['className'] = "anno-".concat(item.type);
    annotationObject['note'] = {
      label: item.annotation,
      title: item.anno_title,
      bgPadding: {
        "top": 15,
        "left": 10,
        "right": 20,
        "bottom": 10
      },
      wrap: widthWrap > 600 ? widthWrap / 5 : widthWrap / 4
    };
    annotationObject['data'] = {
      date: item.date,
      x: item.x,
      r: item.type === 'article' ? RAD_ARTICLE : RAD_PAPER
    };
    annotationObject['dx'] = setXOffset(index, item.x);
    annotationObject['dy'] = removeOverlap(item.anno_title);
    return annotationObject;
  });
  var annotationInsert1 = {};
  annotationInsert1['className'] = 'anno-intro';
  annotationInsert1['note'] = {
    label: 'Here’s a timeline of New York Times articles that mention a relationship between vaccines and autism in the same story in the 1990s.',
    title: 'Historically...',
    bgPadding: {
      "top": 15,
      "left": 10,
      "right": 10,
      "bottom": 10
    },
    wrap: widthWrap > 600 ? widthWrap / 5 : widthWrap / 3.3
  };
  annotationInsert1['data'] = {
    date: new Date('1990-06-01'),
    x: width / 2,
    r: 0
  };
  annotationInsert1['dx'] = -50;
  annotationInsert1['dy'] = 0;
  annotationsFormatted.push(annotationInsert1);
  return annotationsFormatted;
}

function generateAnnotations() {
  var type = d3.annotationCallout;
  var parseTime = d3.timeParse("%d-%b-%y");
  var makeAnnotations = d3.annotation().editMode(false) //also can set and override in the note.padding property
  //of the annotation object
  .notePadding(10).type(type) //accessors & accessorsInverse not needed
  //if using x, y in annotations JSON
  .accessors({
    x: function x(d) {
      return width / 2;
    },
    y: function y(d) {
      return yScale(d.date);
    }
  }).annotations(timelineAnnotationList);
  d3.select("svg.timeline-svg").append("g").attr("class", "annotation-group").call(makeAnnotations);
  d3.selectAll('.anno-article').select('.annotation-note-title').st('fill', '#34A29E');
  d3.selectAll('.anno-paper').select('.annotation-note-title').st('fill', '#ff533d');
  d3.selectAll('.connector').st('stroke', '#c9c9c9');
  d3.selectAll('.note-line').st('stroke', '#c9c9c9');
}

function cleanArticleData(dirtyData) {
  var addedPropertiesData = dirtyData.map(function (item) {
    return _objectSpread({}, item, {
      year: +item.formatted_pub_date.split('/')[0],
      month: +item.formatted_pub_date.split('/')[1],
      day: +item.formatted_pub_date.split('/')[2],
      date: new Date(parseDateArticle(item.formatted_pub_date)),
      yearMonth: "".concat(item.formatted_pub_date.split('/')[0], "-").concat(item.formatted_pub_date.split('/')[1])
    });
  }).sort(_sorting.default.sortDatesYearMonth);
  var filteredPropertiesData = addedPropertiesData.filter(function (item) {
    return item.keywords !== '[]' && item.type_of_material !== 'Correction' && item.print_page !== '' && item.source !== 'International Herald Tribune' && item.type === 'article';
  }); // eslint-disable-next-line no-restricted-syntax

  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = filteredPropertiesData[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      var article = _step.value;
      delete article.filename;
      delete article.keywords;
      delete article.multimedia;
      delete article.news_desk;
      delete article.section_name;
      delete article.snippet;
      delete article.subsection;
      delete article.type_of_material;
      delete article.uri;
      delete article.word_count;
      delete article.blog; // delete article.byline;

      delete article.headline;
      delete article.print_page;
      delete article.source;
      delete article.subsection_name;
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator.return != null) {
        _iterator.return();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  return filteredPropertiesData;
}

function cleanPaperData(dirtyPaperData) {
  var cleanedPaperData = dirtyPaperData.map(function (item) {
    return _objectSpread({}, item, {
      year: +item.pub_date.split('_')[0],
      month: +item.pub_date.split('_')[1],
      date: new Date(parseDatePaper(item.pub_date)) // date: new Date(`${+item.pub_date.split('_')[0]}-${+(item.pub_date.split('_')[1]).replace(/^0+/, '')}-${+(item.pub_date.split('_')[2]).replace(/^0+/, '')}`)

    });
  }); // cleanedPaperData.map(item=>{
  //     console.log(`pub_date field: ${item.pub_date}`)
  //     console.log(`date field ${item.date}`)
  //     console.log(`pub_date PARSED field: ${parseTimetest(item.pub_date)}`)
  // })

  return cleanedPaperData.filter(function (paper) {
    return paper.grouping === 'aap_cochrane' || paper.grouping === 'original';
  });
}

function resize() {
  width = $body.node().offsetWidth;
  height = 6000;
  $svg.at('width', width).at('height', height);
  yScale = d3.scaleTime().domain([new Date(1988, 1, 1), new Date(2019, 10, 15)]).range([margin.top, height - margin.bottom]);
}

function setupDOM() {
  $footer = d3.select('.pudding-footer');
  $coverRight = d3.select('.cover-right');
  $coverLeft = d3.select('.cover-left');
  $body = d3.select('body');
  $svgBox = $body.select('.timeline-box');
  $svg = d3.select('svg.timeline-svg');
  $timeline = $svg.append('g.timeline-g');
  $tooltip = d3.select('.tooltip');
  $tooltipTitle = d3.select('.sci-title');
  $tooltipAuthor = d3.select('.sci-author');
  $tooltipBody = d3.select('.sci-body');
  $tooltipLink = d3.select('.sci-link');
  $buttonArrowCover = d3.select('.arrow-cover');
  $buttonArrowForward = d3.selectAll('.arrow-intro-text-down');
  $buttonArrowBack = d3.selectAll('.arrow-intro-text-up');
  $conclusion = d3.selectAll('.end');
}

function render() {
  generateAnnotations();
  $axisLine = $timeline.append('line.time-axis');
  $axisLine.st('stroke', '#000').st('stroke-width', '0.5px').st('opacity', 1).at('x1', width / 2).at('y1', margin.top).at('x2', width / 2).at('y2', height - margin.bottom);
  $timelineAxis = $timeline.append('g.timeline-axis');
  $timelineCirclesG = $timelineAxis.append('g.timeline-circle-g');
  articlesJoin = $timelineCirclesG.selectAll('g.cells').data(d3.voronoi().extent([[-margin.left, -margin.top], [width + margin.right, height + margin.top]]).x(function (d) {
    return d.x < width + margin.right && d.x > -margin.left ? d.x : 0;
  }).y(function (d) {
    return d.y < height + margin.top && d.y > -margin.top ? d.y : 0;
  }).polygons(mergedData)).enter();
  $articleCells = articlesJoin.append('g.cells');
  $articleCircles = $articleCells.append('circle').at('class', function (d) {
    return d.data.type;
  }).at('cx', function (d) {
    return d.data.x;
  }).at('cy', function (d) {
    return d.data.y;
  }).at('r', function (d) {
    if (d.data.type === 'article') return RAD_ARTICLE;
    return RAD_PAPER;
  }).on('click', function (d) {
    if (width < 600) {
      handleMouseEnter;
    } else {
      d.data.type === 'article' ? window.open(d.data.web_url) : window.open(d.data.link);
    }
  }).on('mousemove', handleMouseEnter).on('mouseleave', handleMouseLeave).on('click', handleMouseEnter);
  $timelineAxisBackground = $timelineAxis.append('g.timeline-axis-background');
  $timelineAxisForeground = $timelineAxis.append('g.timeline-axis-foreground');
  $timelineAxisBackground.at('transform', "translate(".concat(width / 2, ",0)")).call(d3.axisLeft(yScale).ticks(d3.timeYear));
  $timelineAxisForeground.at('transform', "translate(".concat(width / 2, ",0)")).call(d3.axisLeft(yScale).ticks(d3.timeYear));
  $timelineAxisForeground.selectAll('.tick').select('text').st('fill', '#c9c9c9');
  $timelineAxis.selectAll('g.tick').st('font-size', '16px');
  $timelineAxisBackground.selectAll('g.tick').selectAll('text').st('stroke', '#282828').st('stroke-width', '2');
  setNavigationFunctionality();
  $svgBox.classed('hidden', true);
  $footer.classed('hidden', true);

  if (width < 600) {
    $timeline.on('click', handleMouseLeave);
    $timelineAxis.on('click', handleMouseLeave);
    $timelineAxisBackground.on('click', handleMouseLeave);
    $timelineAxisForeground.on('click', handleMouseLeave);
    $svg.on('click', handleMouseLeave);
    d3.selectAll('.annotation').on('click', handleMouseLeave);
  } //     $svg.st('display','none')
  //     $footer.classed('hidden',true)
  // Testing circle issues
  // const middle = d3.select('svg.timeline-svg').at('width')
  // d3.select('.timeline-svg')
  // .append('circle.test-circle')
  // .at('cx',+middle/2)
  // .at('cy',2400)
  // .at('r',500).st('fill','pink')

}

window.onscroll = function () {
  if ($scrollhint.classed('is-visible') === true) {
    $scrollhint.classed('is-visible', false);
  }
};

function init() {
  setupDOM();
  return new Promise(function (resolve, reject) {
    var _d2;

    var articlesFile = 'assets/data/nyt_vaccine_autism_monthly_v2.csv';
    var scienceFile = 'assets/data/science_track_combined.csv';
    var filesList = [];
    filesList.push(articlesFile);
    filesList.push(scienceFile);

    (_d2 = d3).loadData.apply(_d2, filesList.concat([function (error, response) {
      if (error) {
        reject(error);
      } else {
        articleData = response[0];
        paperData = response[1];
        cleanedArticleData = cleanArticleData(articleData);
        cleanedPaperData = cleanPaperData(paperData);
        mergedData = cleanedArticleData.concat(cleanedPaperData).sort(_sorting.default.sortDates);
        resize();
        createSimulation();
        timelineAnnotationList = createTimelineAnnotations(mergedData);
        timelineAnnotationList.forEach(function (item, index) {
          var matchedItem = mergedData.filter(function (newItem) {
            return newItem.date === item.data.date;
          })[0];
          var originalXCoord = null;
          index % 2 ? -200 : 100;

          if (matchedItem) {
            var multiplier = index % 2 ? -1 : 1;
            originalXCoord = matchedItem.x;
            var xCoordWithRadius = matchedItem.type === 'article' ? multiplier * RAD_ARTICLE + originalXCoord : multiplier * RAD_PAPER + originalXCoord;
            item.x = xCoordWithRadius;
          } else {
            item.x = originalXCoord;
          }
        });
        render();
      }
    }]));
  });
}

var _default = {
  init: init,
  resize: resize
};
exports.default = _default;
},{"./sorting":"sorting.js"}],"footer.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var fallbackData = [{
  image: '2018_02_stand-up',
  url: '2018/02/stand-up',
  hed: 'The Structure of Stand-Up Comedy'
}, {
  image: '2018_04_birthday-paradox',
  url: '2018/04/birthday-paradox',
  hed: 'The Birthday Paradox Experiment'
}, {
  image: '2018_11_boy-bands',
  url: '2018/11/boy-bands',
  hed: 'Internet Boy Band Database'
}, {
  image: '2018_08_pockets',
  url: '2018/08/pockets',
  hed: 'Women’s Pockets are Inferior'
}];
var storyData = null;

function loadJS(src, cb) {
  var ref = document.getElementsByTagName('script')[0];
  var script = document.createElement('script');
  script.src = src;
  script.async = true;
  ref.parentNode.insertBefore(script, ref);

  if (cb && typeof cb === 'function') {
    script.onload = cb;
  }

  return script;
}

function loadStories(cb) {
  var request = new XMLHttpRequest();
  var v = Date.now();
  var url = "https://pudding.cool/assets/data/stories.json?v=".concat(v);
  request.open('GET', url, true);

  request.onload = function () {
    if (request.status >= 200 && request.status < 400) {
      var data = JSON.parse(request.responseText);
      cb(data);
    } else cb(fallbackData);
  };

  request.onerror = function () {
    return cb(fallbackData);
  };

  request.send();
}

function createLink(d) {
  return "\n\t<a class='footer-recirc__article' href='https://pudding.cool/".concat(d.url, "' target='_blank'>\n\t\t<img class='article__img' src='https://pudding.cool/common/assets/thumbnails/640/").concat(d.image, ".jpg' alt='").concat(d.hed, "'>\n\t\t<p class='article__headline'>").concat(d.hed, "</p>\n\t</a>\n\t");
}

function recircHTML() {
  var url = window.location.href;
  var html = storyData.filter(function (d) {
    return !url.includes(d.url);
  }).slice(0, 4).map(createLink).join('');
  d3.select('.pudding-footer .footer-recirc__articles').html(html);
}

function setupSocialJS() {
  // facebook
  (function (d, s, id) {
    var js;
    var fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s);
    js.id = id;
    js.src = '//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7';
    fjs.parentNode.insertBefore(js, fjs);
  })(document, 'script', 'facebook-jssdk');

  loadJS('https://platform.twitter.com/widgets.js');
}

function init() {
  loadStories(function (data) {
    storyData = data;
    recircHTML();
    setupSocialJS();
  });
}

var _default = {
  init: init
};
exports.default = _default;
},{}],"main.js":[function(require,module,exports) {
"use strict";

var _lodash = _interopRequireDefault(require("lodash.debounce"));

var _isMobile = _interopRequireDefault(require("./utils/is-mobile"));

var _graphic = _interopRequireDefault(require("./graphic"));

var _footer = _interopRequireDefault(require("./footer"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* global d3 */
var $body = d3.select('body');
var previousWidth = 0;

function resize() {
  // only do resize on width changes, not height
  // (remove the conditional if you want to trigger on height change)
  var width = $body.node().offsetWidth;

  if (previousWidth !== width) {
    previousWidth = width;

    _graphic.default.resize();
  }
}

function setupStickyHeader() {
  var $header = $body.select('header');

  if ($header.classed('is-sticky')) {
    var $menu = $body.select('.header__menu');
    var $toggle = $body.select('.header__toggle');
    $toggle.on('click', function () {
      var visible = $menu.classed('is-visible');
      $menu.classed('is-visible', !visible);
      $toggle.classed('is-visible', !visible);
    });
  }
}

function init() {
  // add mobile class to body tag
  $body.classed('is-mobile', _isMobile.default.any()); // setup resize event

  window.addEventListener('resize', (0, _lodash.default)(resize, 150)); // setup sticky header menu

  setupStickyHeader(); // kick off graphic code

  _graphic.default.init(); // load footer stories


  _footer.default.init();
}

init();
},{"lodash.debounce":"../../node_modules/lodash.debounce/index.js","./utils/is-mobile":"utils/is-mobile.js","./graphic":"graphic.js","./footer":"footer.js"}]},{},["main.js"], null)
//# sourceMappingURL=/main.js.map